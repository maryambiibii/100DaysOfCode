with open("./Input/Names/invited_names.txt") as name:
    names = name.readlines()

with open("Input/Letters/starting_letter.txt") as letter:
    letter_template = letter.readlines()

for name in names:
    with open(f"Output/ReadyToSend/letter_to_{name}", mode="a") as letter_to:
        for line in letter_template:
            if "[name]" in line:
                sentence = line.replace("[name]", f"{name}")
                complete_sentence = sentence.replace("\n", '')
                letter_to.write(complete_sentence)
                letter_to.write("\n")
            else:
                letter_to.write(line)
